import json
from pathlib import Path
from typing import Dict, Optional

class CustomCommands:
    def __init__(self, data_path: Path):
        self.file_path = data_path / 'custom_commands.json'
        self.commands: Dict[str, str] = {}
        self._load()

    def _load(self):
        if self.file_path.exists():
            try:
                with open(self.file_path, 'r', encoding='utf-8') as f:
                    self.commands = json.load(f)
            except:
                self.commands = {}

    def _save(self):
        self.file_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.file_path, 'w', encoding='utf-8') as f:
            json.dump(self.commands, f, ensure_ascii=False, indent=2)

    def add(self, alias: str, target_command: str) -> bool:
        alias = alias.lower().strip()
        if not alias or not target_command:
            return False
        self.commands[alias] = target_command.strip()
        self._save()
        return True

    def remove(self, alias: str) -> bool:
        alias = alias.lower().strip()
        if alias in self.commands:
            del self.commands[alias]
            self._save()
            return True
        return False

    def get(self, alias: str) -> Optional[str]:
        return self.commands.get(alias.lower().strip())

    def list_aliases(self) -> str:
        if not self.commands:
            return "Нет сохранённых команд."
        return "\n".join(f"• {alias} → {cmd}" for alias, cmd in self.commands.items())