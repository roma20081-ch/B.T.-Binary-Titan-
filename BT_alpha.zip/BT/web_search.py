import aiohttp
import ssl
from bs4 import BeautifulSoup
from ddgs import DDGS
import logging

logger = logging.getLogger(__name__)

class WebSearcher:
    def __init__(self):
        self._session = None

    async def _get_session(self):
        if self._session is None:
            # Создаём коннектор с отключённой проверкой SSL
            connector = aiohttp.TCPConnector(ssl=False)
            self._session = aiohttp.ClientSession(connector=connector)
        return self._session

    async def search_and_extract(self, query: str, max_chars: int = 3000) -> str:
        try:
            # Поиск через DDGS (синхронный, но быстрый)
            with DDGS() as ddgs:
                results = list(ddgs.text(query, max_results=1))
                if not results:
                    return None

            first_url = results[0]['href']
            logger.info(f"Поиск: {query} → {first_url}")

            # Загружаем страницу (без проверки SSL)
            session = await self._get_session()
            async with session.get(first_url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status != 200:
                    return None
                html = await resp.text()

            # Извлекаем текст
            soup = BeautifulSoup(html, 'lxml')
            for tag in soup(['script', 'style', 'nav', 'footer', 'header']):
                tag.decompose()
            text = soup.get_text(separator=' ', strip=True)
            return text[:max_chars]

        except Exception as e:
            logger.error(f"Ошибка поиска: {e}")
            return None

    async def close(self):
        if self._session:
            await self._session.close()