import json
import time
from pathlib import Path
from typing import Dict, List, Optional

class ReminderManager:
    def __init__(self, data_path: Path):
        self.file_path = data_path / 'reminders.json'
        self.reminders: List[Dict] = []
        self._load()

    def _load(self):
        if self.file_path.exists():
            with open(self.file_path, 'r', encoding='utf-8') as f:
                self.reminders = json.load(f)

    def _save(self):
        self.file_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.file_path, 'w', encoding='utf-8') as f:
            json.dump(self.reminders, f, ensure_ascii=False, indent=2)

    def add_reminder(self, user_id: str, channel_id: str, 
                     message: str, remind_time: float) -> int:
        """Добавляет напоминание, возвращает ID записи"""
        reminder = {
            'id': int(time.time() * 1000),
            'user_id': user_id,
            'channel_id': channel_id,
            'message': message,
            'remind_time': remind_time
        }
        self.reminders.append(reminder)
        self._save()
        return reminder['id']

    def get_due_reminders(self, current_time: float) -> List[Dict]:
        """Возвращает просроченные напоминания и удаляет их из хранилища"""
        due = []
        remaining = []
        for rem in self.reminders:
            if rem['remind_time'] <= current_time:
                due.append(rem)
            else:
                remaining.append(rem)
        if due:
            self.reminders = remaining
            self._save()
        return due

    def remove_reminder(self, reminder_id: int) -> bool:
        """Удаляет напоминание по ID"""
        for rem in self.reminders:
            if rem['id'] == reminder_id:
                self.reminders.remove(rem)
                self._save()
                return True
        return False

    def list_reminders(self, user_id: str) -> str:
        """Список активных напоминаний пользователя"""
        user_rems = [r for r in self.reminders if r['user_id'] == user_id]
        if not user_rems:
            return "Нет активных напоминаний."
        text = ""
        for r in user_rems:
            time_str = time.strftime('%d.%m.%Y %H:%M', time.localtime(r['remind_time']))
            text += f"• ID:{r['id']} [{time_str}] {r['message']}\n"
        return text