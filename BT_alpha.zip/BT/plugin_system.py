import importlib.util
import json
import sys
from pathlib import Path
from typing import Dict, List
import inspect
import logging

logger = logging.getLogger(__name__)

class PluginSystem:
    def __init__(self, plugins_path: Path):
        self.plugins_path = Path(plugins_path)
        self.plugins_path.mkdir(parents=True, exist_ok=True)
        self.loaded_plugins = {}
        self.hooks = {
            'on_message': [],
            'on_command': [],
            'on_startup': [],
            'on_shutdown': []
        }

    async def load_plugins(self):
        for plugin_dir in self.plugins_path.iterdir():
            if plugin_dir.is_dir() and (plugin_dir / 'manifest.json').exists():
                await self.load_plugin(plugin_dir)
        logger.info(f"🔌 Загружено плагинов: {len(self.loaded_plugins)}")

    async def load_plugin(self, plugin_path: Path):
        try:
            with open(plugin_path / 'manifest.json', 'r', encoding='utf-8') as f:
                manifest = json.load(f)
            if not self._check_dependencies(manifest.get('dependencies', [])):
                return
            main_file = plugin_path / manifest.get('main', 'main.py')
            if main_file.exists():
                spec = importlib.util.spec_from_file_location(manifest['name'], main_file)
                module = importlib.util.module_from_spec(spec)
                sys.modules[manifest['name']] = module
                spec.loader.exec_module(module)
                if hasattr(module, 'Plugin'):
                    plugin_instance = module.Plugin()
                    for hook_name in self.hooks.keys():
                        if hasattr(plugin_instance, hook_name):
                            self.hooks[hook_name].append(getattr(plugin_instance, hook_name))
                    self.loaded_plugins[manifest['name']] = {
                        'instance': plugin_instance,
                        'manifest': manifest,
                        'path': plugin_path
                    }
                    logger.info(f"✅ Плагин {manifest['name']} v{manifest['version']} загружен")
        except Exception as e:
            logger.error(f"❌ Ошибка загрузки плагина {plugin_path.name}: {e}")

    def _check_dependencies(self, dependencies: List[str]) -> bool:
        for dep in dependencies:
            try:
                importlib.import_module(dep)
            except ImportError:
                return False
        return True

    async def execute_hook(self, hook_name: str, *args, **kwargs):
        results = []
        for hook in self.hooks.get(hook_name, []):
            try:
                if inspect.iscoroutinefunction(hook):
                    result = await hook(*args, **kwargs)
                else:
                    result = hook(*args, **kwargs)
                results.append(result)
            except Exception as e:
                logger.error(f"Ошибка в хуке {hook_name}: {e}")
        return results

    def get_loaded_plugins(self) -> List[Dict]:
        return [{'name': data['manifest']['name'],
                 'version': data['manifest']['version'],
                 'description': data['manifest'].get('description', 'Нет описания')}
                for data in self.loaded_plugins.values()]