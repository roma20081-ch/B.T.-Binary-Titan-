$taskName = "BTAssistant"
$pythonPath = "C:\Users\You\Desktop\BT\venv\Scripts\python.exe"
$scriptPath = "C:\Users\You\Desktop\BT\main.py"
$workingDir = "C:\Users\You\Desktop\BT"

$action = New-ScheduledTaskAction -Execute $pythonPath -Argument "`"$scriptPath`"" -WorkingDirectory $workingDir
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
$trigger.Delay = "PT30S"   # задержка 30 секунд после входа
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)

Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Settings $settings -Force
Write-Host "Задача для бота создана. Бот будет запускаться через 30 секунд после входа."