import asyncio
import logging
import time
from pathlib import Path
from config import config
from resource_monitor import ResourceMonitor
from memory_manager import MemoryManager
from ai_manager import AIManager
from task_queue import TaskQueue, TaskPriority
from discord_bot import DiscordBot
from plugin_system import PluginSystem
from windows_controller import WindowsController
from scenario_manager import ScenarioManager
from reminder_manager import ReminderManager
from news_fetcher import NewsFetcher
from web_search import WebSearcher
from weather import Weather


# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(config.logs_path / 'bot.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

class BTAssistant:
    """Главный класс ассистента"""
    
    def __init__(self):
        logger.info("🚀 Инициализация BT Assistant...")
        
        MY_DISCORD_ID = "766676830416797696"  # Твой Discord ID
        
        self.resource_monitor = ResourceMonitor()
        self.memory_manager = MemoryManager(
            config.memory_path,
            config.cache_path,
            config.max_memory_entries,
            config.cache_ttl,
            config.max_cache_size_mb
        )
        self.ai_manager = AIManager(
            self.resource_monitor,
            self.memory_manager
        )
        self.task_queue = TaskQueue(
            config.max_queue_size,
            config.max_concurrent_tasks
        )
        self.plugin_system = PluginSystem(config.plugins_path)
        self.windows_controller = WindowsController(
            admin_user_ids=[MY_DISCORD_ID]
        )
        self.scenario_manager = ScenarioManager(config.data_path)
        self.news_fetcher = NewsFetcher()
        self.weather = Weather("Наро-Фоминск")
        self.reminder_manager = ReminderManager(config.data_path)
        self.discord_bot = None
        self.config = config
        self.force_model = None  # None = авто, 'fast', 'medium', 'powerful'
        self.web_searcher = WebSearcher()
        
    async def start(self):
        logger.info("🔄 Запуск систем...")
        await self.resource_monitor.start_monitoring()
        await self.ai_manager.initialize()
        await self.plugin_system.load_plugins()
        asyncio.create_task(self.task_queue.process_queue())
        asyncio.create_task(self._check_reminders_loop())
        self.discord_bot = DiscordBot(self)
        logger.info("✅ Все системы запущены")
        print("\n" + "="*50)
        print("🤖 BT Assistant готов к работе!")
        print("="*50 + "\n")
        await self.discord_bot.start()
        
    async def stop(self):
        logger.info("🛑 Остановка систем...")
        await self.resource_monitor.stop_monitoring()
        await self.ai_manager.cleanup()
        await self.plugin_system.execute_hook('on_shutdown')
        logger.info("👋 До свидания!")

    async def _check_reminders_loop(self):
        """Фоновая проверка напоминаний каждые 30 секунд"""
        while True:
            await asyncio.sleep(30)
            try:
                now = time.time()
                due = self.reminder_manager.get_due_reminders(now)
                for rem in due:
                    channel = self.discord_bot.bot.get_channel(int(rem['channel_id']))
                    if channel:
                        await channel.send(
                            f"⏰ **Напоминание** <@{rem['user_id']}>: {rem['message']}"
                        )
            except Exception as e:
                logger.error(f"Ошибка проверки напоминаний: {e}")
        
    async def process_message(self, message_content: str, user_id: str = None) -> str:
        """Обработка сообщения с возможным выполнением системных команд"""
        msg = message_content.strip()
        msg_lower = msg.lower()

        # --- Сценарии (точное совпадение) ---
        scenario_actions = self.scenario_manager.get_scenario(msg_lower)
        if scenario_actions:
            logger.info(f"🎭 Выполнение сценария: {msg_lower}")
            results = []
            for action in scenario_actions:
                try:
                    parts = action.split(':', 1)
                    if len(parts) != 2:
                        continue
                    cmd_type, value = parts[0].strip(), parts[1].strip()
                    if cmd_type == 'open':
                        res = await self.windows_controller.run_command(value, user_id)
                    elif cmd_type == 'site':
                        res = self.windows_controller.open_site(value, user_id)
                    elif cmd_type == 'volume':
                        res = self.windows_controller.set_volume(int(value), user_id)
                    elif cmd_type == 'close':
                        res = self.windows_controller.close_window(value, user_id)
                    elif cmd_type == 'minimize':
                        res = self.windows_controller.minimize_window(value, user_id)
                    elif cmd_type == 'run':
                        res = await self.windows_controller.run_command(value, user_id)
                    else:
                        res = f"❌ Неизвестный тип действия: {cmd_type}"
                    results.append(res)
                except Exception as e:
                    results.append(f"❌ Ошибка: {e}")
            return "✅ Сценарий выполнен:\n" + "\n".join(results)

        # --- Новости ---
        if msg_lower in ('новости', 'сводка новостей', 'последние новости'):
            news_list = await self.news_fetcher.fetch_rss(source='rbc', limit=5)
            if not news_list:
                return "❌ Не удалось получить новости"
            news_text = "\n".join([f"- {title}: {desc}" for title, desc in news_list])
            summary = await self.ai_manager.query_model(
                'powerful',
                f"Сделай краткую сводку следующих новостей (до 5 предложений):\n{news_text}",
                system_prompt="Ты – помощник, который делает сжатые и информативные сводки новостей на русском языке."
            )
            return f"📰 **Сводка новостей:**\n{summary}"
                
        # --- Погода (временная диагностика) ---
        if msg_lower in ('погода', 'какая погода', 'сколько градусов'):
            city = "Наро-Фоминск"
            parts = msg.split(' в ')
            if len(parts) > 1:
                city = parts[-1].strip()
            return await self.weather.get_weather(city)

        # --- Поиск в интернете ---
        if msg_lower.startswith(('найди', 'поищи', 'search', 'загугли', 'что такое')):
            # Убираем ключевое слово
            query = msg
            for word in ['найди', 'поищи', 'search', 'загугли']:
                if msg_lower.startswith(word):
                    query = msg[len(word):].strip()
                    break
            if not query:
                return "❌ Укажите, что искать"
            
            logger.info(f"🔍 Поиск: {query}")
            page_text = await self.web_searcher.search_and_extract(query)
            if not page_text:
                return "❌ Не удалось найти информацию в интернете"
            
            # Суммаризируем через среднюю или мощную модель
            summary = await self.ai_manager.query_model(
                'powerful',
                f"Прочитай текст и дай краткий, информативный ответ на русском языке (2-4 предложения), "
                f"основанный на следующей информации:\n\n{page_text}\n\nЗапрос: {query}",
                system_prompt="Ты — полезный ассистент, который кратко отвечает на вопросы, используя предоставленный текст."
            )
            return f"🔍 **Результат поиска:**\n{summary}"
        # --- Громкость ---
        if msg_lower.startswith('громкость'):
            parts = msg.split()
            if len(parts) == 1:
                return self.windows_controller.get_volume(user_id)
            try:
                level = int(parts[1])
                return self.windows_controller.set_volume(level, user_id)
            except (ValueError, IndexError):
                pass
        if msg_lower in ('без звука', 'выключить звук', 'mute'):
            return self.windows_controller.mute(user_id)

        # --- Команды без префикса (по ключевым словам) ---
        # 1. Открытие сайтов
        if msg_lower.startswith(('открой сайт', 'сайт', 'открой страницу')):
            parts = msg.split(maxsplit=2)
            site_alias = parts[-1] if len(parts) > 1 else ""
            if site_alias:
                return self.windows_controller.open_site(site_alias, user_id)
            else:
                return "❌ Укажите название сайта"

        # 2. Открытие файлов с рабочего стола
        if msg_lower.startswith(('открой файл', 'открой ярлык', 'запусти файл')):
            parts = msg.split(maxsplit=2)
            file_name = parts[-1] if len(parts) > 1 else ""
            if file_name:
                return self.windows_controller.open_desktop_file(file_name, user_id)
            else:
                return "❌ Укажите имя файла или ярлыка"

        # 3. Закрытие окна
        if msg_lower.startswith(('закрой окно', 'закрой', 'закрыть')):
            parts = msg.split(maxsplit=1)
            title_part = parts[-1] if len(parts) > 1 else ""
            if title_part:
                return self.windows_controller.close_window(title_part, user_id)
            else:
                return "❌ Укажите название окна"

        # 4. Сворачивание окна
        if msg_lower.startswith(('сверни окно', 'сверни', 'свернуть')):
            parts = msg.split(maxsplit=1)
            title_part = parts[-1] if len(parts) > 1 else ""
            if title_part:
                return self.windows_controller.minimize_window(title_part, user_id)
            else:
                return "❌ Укажите название окна"

        # 5. Показать окна
        if msg_lower in ('покажи окна', 'список окон', 'какие окна', 'окна', 'windows'):
            return self.windows_controller.list_windows(user_id)

        # --- Обычные запуски приложений ---
        if msg_lower.startswith(('открой', 'запусти', 'выполни')):
            parts = msg.split(maxsplit=1)
            if len(parts) > 1:
                command = parts[1]
                logger.info(f"🖥️ Windows команда от {user_id}: {command}")
                return await self.windows_controller.run_command(command, user_id)

        # --- Если принудительно выбрана модель, используем её ---
        if self.force_model:
            try:
                response = await self.ai_manager.query_model(
                    self.force_model,
                    message_content
                )
                return response
            except Exception as e:
                logger.error(f"Ошибка принудительной модели: {e}")
                return f"❌ Ошибка модели {self.force_model}: {e}"

        # --- Стандартная обработка через нейросеть ---
        complexity = await self.ai_manager.analyze_complexity(message_content)
        logger.info(f"📝 Запрос: {message_content[:50]}... | Сложность: {complexity}")
        
        if complexity == 'powerful':
            priority = TaskPriority.HIGH
        elif complexity == 'medium':
            priority = TaskPriority.NORMAL
        else:
            priority = TaskPriority.LOW
            
        try:
            response = await self.task_queue.add_task(
                self.ai_manager.query_model,
                complexity,
                message_content,
                priority=priority
            )
            return response
        except Exception as e:
            logger.error(f"Ошибка обработки сообщения: {e}")
            return "❌ Извините, произошла ошибка при обработке запроса."

async def main():
    assistant = BTAssistant()
    try:
        await assistant.start()
    except KeyboardInterrupt:
        logger.info("Получен сигнал остановки (Ctrl+C)")
    except Exception as e:
        logger.error(f"Критическая ошибка: {e}", exc_info=True)
    finally:
        await assistant.stop()

if __name__ == '__main__':
    if hasattr(asyncio, 'WindowsSelectorEventLoopPolicy'):
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    asyncio.run(main())