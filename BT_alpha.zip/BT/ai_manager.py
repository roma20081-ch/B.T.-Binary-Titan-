import aiohttp
import asyncio
import json
from typing import Dict, Optional, List
from config import config
from resource_monitor import ResourceMonitor
from memory_manager import MemoryManager
import logging

logger = logging.getLogger(__name__)

class AIManager:
    def __init__(self, resource_monitor: ResourceMonitor, memory_manager: MemoryManager):
        self.host = config.ollama_host
        self.models = config.models
        self.resource_monitor = resource_monitor
        self.memory_manager = memory_manager
        self.stats = {name: {'calls': 0, 'tokens': 0, 'errors': 0} for name in self.models}
        self._session = None

    async def initialize(self):
        self._session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=config.ollama_timeout))
        available = await self._get_available_models()
        logger.info(f"📋 Доступные модели в Ollama: {available}")
        for mtype, mcfg in self.models.items():
            if mcfg.name not in available:
                logger.warning(f"⚠️ Модель {mcfg.name} не найдена, пытаюсь загрузить...")
                await self._pull_model(mcfg.name)
            else:
                logger.info(f"✅ Модель {mcfg.name} доступна")

    async def _get_available_models(self) -> List[str]:
        try:
            async with self._session.get(f"{self.host}/api/tags") as resp:
                if resp.status == 200:
                    data = await resp.json()
                    models = []
                    for model in data.get('models', []):
                        name = model['name'].split(':')[0] if ':' in model['name'] else model['name']
                        models.append(name)
                    return models
        except Exception as e:
            logger.error(f"Ошибка получения моделей: {e}")
        return []

    async def _pull_model(self, model_name: str) -> bool:
        try:
            logger.info(f"📥 Загружаю {model_name}...")
            async with self._session.post(f"{self.host}/api/pull", json={"name": model_name}) as resp:
                return resp.status == 200
        except Exception as e:
            logger.error(f"Ошибка загрузки модели: {e}")
            return False

    async def analyze_complexity(self, message: str) -> str:
        """Улучшенный анализатор сложности запроса"""
        msg_lower = message.lower()
        msg_len = len(message)

        # Ключевые слова, требующие мощной модели (код, майнер, детальный анализ)
        powerful_keywords = [
            'напиши код', 'функци', 'класс', 'алгоритм', 'программ', 'скрипт',
            'code', 'function', 'python', 'javascript', 'import', 'def ', 'class ',
            '```', 'debug', 'ошибка в коде', 'напиши программу', 'создай скрипт',
            'майнер', 'майнинг', 'блокчейн', 'крипто', 'c#', 'c++', 'java',
            'подробно объясни', 'развернутый ответ', 'анализ', 'исследование'
        ]

        # Ключевые слова для средней модели (диалоги, объяснения)
        medium_keywords = [
            'объясни', 'расскажи', 'почему', 'как работает', 'что такое',
            'история', 'совет', 'рекомендация'
        ]

        # Проверка на мощные ключевые слова
        if any(kw in msg_lower for kw in powerful_keywords):
            return 'powerful'

        # Если сообщение очень длинное – тоже мощная модель
        if msg_len > 300:
            return 'powerful'

        # Проверка на средние ключевые слова
        if any(kw in msg_lower for kw in medium_keywords):
            return 'medium'

        # Если сообщение короткое – быстрая модель
        if msg_len < 50:
            return 'fast'

        # Всё остальное – средняя
        return 'medium'

    async def query_model(self, model_type: str, prompt: str,
                          system_prompt: Optional[str] = None, use_cache: bool = True) -> str:
        if model_type not in self.models:
            raise ValueError(f"Неизвестный тип модели: {model_type}")
        model_config = self.models[model_type]
        if not self.resource_monitor.can_run_model(model_config.min_ram_gb, model_config.min_vram_gb):
            logger.warning(f"⚠️ Недостаточно ресурсов для {model_type}")
            if model_type == 'powerful':
                model_type = 'medium'
                model_config = self.models[model_type]
            elif model_type == 'medium':
                model_type = 'fast'
                model_config = self.models[model_type]
        if use_cache and config.cache_enabled:
            cached = await self.memory_manager.get_from_cache(prompt, model_config.name)
            if cached:
                self.stats[model_type]['calls'] += 1
                return cached
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        payload = {
            "model": model_config.name,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": model_config.temperature,
                "num_predict": model_config.max_tokens,
                "num_ctx": model_config.context_window
            }
        }
        try:
            async with self._session.post(f"{self.host}/api/chat", json=payload) as resp:
                if resp.status == 200:
                    result = await resp.json()
                    response_text = result['message']['content']
                    self.stats[model_type]['calls'] += 1
                    self.stats[model_type]['tokens'] += result.get('eval_count', 0)
                    if use_cache and config.cache_enabled:
                        await self.memory_manager.add_to_cache(prompt, model_config.name, response_text)
                    return response_text
                else:
                    error_text = await resp.text()
                    raise Exception(f"API error {resp.status}: {error_text}")
        except Exception as e:
            self.stats[model_type]['errors'] += 1
            logger.error(f"❌ Ошибка запроса к {model_config.name}: {e}")
            return f"❌ Ошибка при обработке запроса: {str(e)}"

    def get_stats(self) -> Dict:
        return self.stats

    async def cleanup(self):
        if self._session:
            await self._session.close()