$taskName = "BTAssistant"
$pythonPath = "C:\Users\You\Desktop\BT\venv\Scripts\python.exe"
$scriptPath = "C:\Users\You\Desktop\BT\main.py"
$workingDir = "C:\Users\You\Desktop\BT"

$action = New-ScheduledTaskAction -Execute $pythonPath -Argument "`"$scriptPath`"" -WorkingDirectory $workingDir
$trigger = New-ScheduledTaskTrigger -AtLogOn
$trigger.Delay = "PT30S"   # задержка 30 секунд после входа

# Настройки: скрытое окно, перезапуск при сбое
$settings = New-ScheduledTaskSettingsSet `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -StartWhenAvailable `
    -RestartCount 3 `
    -RestartInterval (New-TimeSpan -Minutes 1) `
    -Hidden

# Учётная запись с высшими правами (как у VPN)
$principal = New-ScheduledTaskPrincipal `
    -UserId "$env:USERDOMAIN\$env:USERNAME" `
    -LogonType Interactive `
    -RunLevel Highest

Register-ScheduledTask -TaskName $taskName `
    -Action $action `
    -Trigger $trigger `
    -Principal $principal `
    -Settings $settings `
    -Force

Write-Host "Задача для бота создана с правами администратора."