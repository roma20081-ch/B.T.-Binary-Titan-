import asyncio
from dataclasses import dataclass, field
from typing import Any, Callable
from enum import Enum
import time
import logging

logger = logging.getLogger(__name__)

class TaskPriority(Enum):
    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3

@dataclass(order=True)
class Task:
    priority: int
    created_at: float = field(compare=False)
    task_id: str = field(compare=False)
    func: Callable = field(compare=False)
    args: tuple = field(compare=False)
    kwargs: dict = field(compare=False)
    future: asyncio.Future = field(compare=False)

class TaskQueue:
    def __init__(self, max_size=100, max_concurrent=2):
        self.queue = asyncio.PriorityQueue(maxsize=max_size)
        self.max_concurrent = max_concurrent
        self._running_tasks = 0
        self._lock = asyncio.Lock()

    async def add_task(self, func, *args, priority=TaskPriority.NORMAL, **kwargs):
        future = asyncio.Future()
        task = Task(priority=priority.value * -1, created_at=time.time(),
                    task_id=f"task_{int(time.time()*1000)}",
                    func=func, args=args, kwargs=kwargs, future=future)
        await self.queue.put(task)
        return await future

    async def process_queue(self):
        while True:
            async with self._lock:
                if self._running_tasks >= self.max_concurrent:
                    await asyncio.sleep(0.1)
                    continue
            try:
                task = await asyncio.wait_for(self.queue.get(), timeout=1.0)
            except asyncio.TimeoutError:
                continue
            self._running_tasks += 1
            asyncio.create_task(self._execute_task(task))

    async def _execute_task(self, task):
        try:
            result = await task.func(*task.args, **task.kwargs)
            task.future.set_result(result)
        except Exception as e:
            logger.error(f"❌ Ошибка задачи: {e}")
            task.future.set_exception(e)
        finally:
            self._running_tasks -= 1