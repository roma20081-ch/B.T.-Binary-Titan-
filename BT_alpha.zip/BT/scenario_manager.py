import json
from pathlib import Path
from typing import Dict, List

class ScenarioManager:
    def __init__(self, data_path: Path):
        self.file_path = data_path / 'scenarios.json'
        self.scenarios: Dict[str, List[str]] = {}
        self._load()

    def _load(self):
        if self.file_path.exists():
            with open(self.file_path, 'r', encoding='utf-8') as f:
                self.scenarios = json.load(f)

    def _save(self):
        self.file_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.file_path, 'w', encoding='utf-8') as f:
            json.dump(self.scenarios, f, ensure_ascii=False, indent=2)

    def add_scenario(self, trigger: str, actions: List[str]):
        self.scenarios[trigger.lower().strip()] = actions
        self._save()

    def remove_scenario(self, trigger: str) -> bool:
        trigger = trigger.lower().strip()
        if trigger in self.scenarios:
            del self.scenarios[trigger]
            self._save()
            return True
        return False

    def get_scenario(self, trigger: str):
        return self.scenarios.get(trigger.lower().strip())

    def list_scenarios(self) -> str:
        if not self.scenarios:
            return "Нет сценариев."
        result = ""
        for trigger, actions in self.scenarios.items():
            result += f"• {trigger} → {'; '.join(actions)}\n"
        return result