import aiohttp
from bs4 import BeautifulSoup
from typing import List, Tuple
import logging

logger = logging.getLogger(__name__)

class NewsFetcher:
    RSS_FEEDS = {
        'rbc': 'https://rssexport.rbc.ru/rbcnews/news/20/full.rss',
        'lenta': 'https://lenta.ru/rss/news',
        'ria': 'https://ria.ru/export/rss2/archive/index.xml',
    }

    def __init__(self):
        self._session = None

    async def _get_session(self):
        if self._session is None:
            self._session = aiohttp.ClientSession()
        return self._session

    async def fetch_rss(self, source: str = 'rbc', limit: int = 5) -> List[Tuple[str, str]]:
        # Пробуем указанный источник, при неудаче — lenta
        for src in (source, 'lenta'):
            url = self.RSS_FEEDS.get(src)
            if not url:
                continue
            try:
                session = await self._get_session()
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                    if resp.status == 200:
                        xml = await resp.text()
                        soup = BeautifulSoup(xml, 'xml')
                        items = soup.find_all('item')[:limit]
                        if not items:
                            continue
                        news = []
                        for item in items:
                            title = item.find('title').text if item.find('title') else ''
                            desc = item.find('description').text if item.find('description') else ''
                            news.append((title, desc))
                        return news
                    else:
                        logger.warning(f"RSS {src} вернул статус {resp.status}")
            except Exception as e:
                logger.error(f"Ошибка получения RSS {src}: {e}")
        return []

    async def close(self):
        if self._session:
            await self._session.close()