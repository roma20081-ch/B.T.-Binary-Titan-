import asyncio
import subprocess
import os
import webbrowser
import psutil
import pyautogui
import logging
from pathlib import Path
from typing import Optional, List
from custom_commands import CustomCommands

logger = logging.getLogger(__name__)

class WindowsController:
    """Безопасный контроллер Windows-команд"""

    ALLOWED_APPS = {
        'notepad': 'notepad.exe',
        'calc': 'calc.exe',
        'explorer': 'explorer.exe',
        'cmd': 'cmd.exe',
        'powershell': 'powershell.exe',
        'taskmgr': 'taskmgr.exe',
        'chrome': 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
        'vscode': 'C:\\Users\\%USERNAME%\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe',
        'spotify': 'C:\\Users\\%USERNAME%\\AppData\\Roaming\\Spotify\\Spotify.exe',
        'steam': 'C:\\Program Files (x86)\\Steam\\Steam.exe',
        'discord': 'explorer.exe shell:AppsFolder\\com.squirrel.Discord.Discord',
    }

    ALLOWED_COMMANDS = [
        'tasklist', 'systeminfo', 'ipconfig', 'whoami', 'hostname',
        'dir', 'echo', 'date', 'time', 'ver'
    ]

    APP_ALIASES = {
        'стим': 'steam',
        'блокнот': 'notepad',
        'калькулятор': 'calc',
        'проводник': 'explorer',
        'командная строка': 'cmd',
        'powershell': 'powershell',
        'диспетчер задач': 'taskmgr',
        'хром': 'chrome',
        'гугл хром': 'chrome',
        'вскод': 'vscode',
        'спотифай': 'spotify',
        'дискорд': 'discord',
    }

    SITES = {
        'вк': 'https://vk.com/feed',
        'vk': 'https://vk.com/feed',
        'ютуб': 'https://www.youtube.com/',
        'youtube': 'https://www.youtube.com/',
        'дипсик': 'https://chat.deepseek.com/',
        'deepseek': 'https://chat.deepseek.com/',
    }

    def __init__(self, admin_user_ids: Optional[List[str]] = None):
        self.admin_user_ids = admin_user_ids or []
        self.custom_commands = CustomCommands(Path("data"))

    def is_authorized(self, user_id: str) -> bool:
        if not self.admin_user_ids:
            return True
        return user_id in self.admin_user_ids

    def _expand_path(self, path: str) -> str:
        return os.path.expandvars(path)

    # ---------- Громкость (эмуляция клавиш) ----------
    def set_volume(self, percent: int, user_id: str) -> str:
        """Устанавливает громкость (0-100) через эмуляцию клавиш"""
        if not self.is_authorized(user_id):
            return "❌ У вас нет прав"
        if not 0 <= percent <= 100:
            return "❌ Громкость должна быть от 0 до 100"
        try:
            # Сбрасываем в 0 многократным нажатием Volume Down
            for _ in range(50):
                pyautogui.press('volumedown')
            # Поднимаем до нужного уровня (1 нажатие ≈ 2%)
            steps = int(percent / 2)
            for _ in range(steps):
                pyautogui.press('volumeup')
            return f"🔊 Громкость установлена примерно на {percent}%"
        except Exception as e:
            logger.error(f"Ошибка установки громкости: {e}")
            return "❌ Не удалось установить громкость"

    def get_volume(self, user_id: str) -> str:
        """Текущая громкость (при эмуляции точное значение недоступно)"""
        return "🔊 Используйте системный индикатор для проверки громкости"

    def mute(self, user_id: str) -> str:
        """Переключает mute (вкл/выкл) через клавишу"""
        if not self.is_authorized(user_id):
            return "❌ У вас нет прав"
        try:
            pyautogui.press('volumemute')
            return "🔇 Звук переключён"
        except Exception as e:
            return f"❌ Ошибка: {e}"

    # ---------- Запуск программ и команд ----------
    async def run_command(self, command: str, user_id: str) -> str:
        if not self.is_authorized(user_id):
            return "❌ У вас нет прав"

        parts = command.strip().split()
        if not parts:
            return "❌ Пустая команда"

        base_cmd = parts[0].lower()

        # пользовательские алиасы
        custom_cmd = self.custom_commands.get(base_cmd)
        if custom_cmd:
            command = custom_cmd + ' ' + ' '.join(parts[1:])
            parts = command.strip().split()
            if parts:
                base_cmd = parts[0].lower()

        # встроенные русские алиасы
        if base_cmd in self.APP_ALIASES:
            base_cmd = self.APP_ALIASES[base_cmd]
            command = base_cmd + ' ' + ' '.join(parts[1:])
            parts = command.strip().split()
            if parts:
                base_cmd = parts[0].lower()

        # запуск приложения
        if base_cmd in self.ALLOWED_APPS:
            app_path = self._expand_path(self.ALLOWED_APPS[base_cmd])
            try:
                subprocess.Popen(app_path, shell=True)
                return f"✅ Запущено: {base_cmd}"
            except Exception as e:
                logger.error(f"Ошибка запуска {base_cmd}: {e}")
                return f"❌ Не удалось запустить {base_cmd}: {e}"

        # системные команды
        if base_cmd in self.ALLOWED_COMMANDS:
            try:
                proc = await asyncio.create_subprocess_shell(
                    command,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, stderr = await proc.communicate()
                if proc.returncode == 0:
                    output = stdout.decode('cp866', errors='ignore').strip()
                    return f"```\n{output[:1500]}\n```" if output else "✅ Команда выполнена"
                else:
                    error = stderr.decode('cp866', errors='ignore').strip()
                    return f"❌ Ошибка: {error[:500]}"
            except Exception as e:
                return f"❌ Ошибка выполнения команды: {e}"

        return f"❌ Команда `{base_cmd}` не разрешена"

    # ---------- Управление окнами ----------
    def _get_window_by_title(self, title_part: str):
        import pygetwindow as gw
        windows = gw.getWindowsWithTitle(title_part)
        if not windows:
            for win in gw.getAllWindows():
                if title_part.lower() in win.title.lower():
                    return win
            return None
        return windows[0]

    def list_windows(self, user_id: str) -> str:
        if not self.is_authorized(user_id):
            return "❌ У вас нет прав"
        try:
            import pygetwindow as gw
            windows = [win for win in gw.getAllWindows() if win.title.strip()]
            if not windows:
                return "ℹ️ Нет открытых окон"
            msg = "🪟 **Открытые окна:**\n"
            for i, win in enumerate(windows[:15], 1):
                msg += f"{i}. {win.title[:80]}\n"
            return msg
        except Exception as e:
            return f"❌ Ошибка получения списка окон: {e}"

    def close_window(self, title_part: str, user_id: str) -> str:
        if not self.is_authorized(user_id):
            return "❌ У вас нет прав"
        try:
            win = self._get_window_by_title(title_part)
            if win:
                win.close()
                return f"✅ Окно `{win.title[:50]}` закрыто"
            else:
                return f"❌ Окно с заголовком, содержащим `{title_part}`, не найдено"
        except Exception as e:
            return f"❌ Ошибка закрытия окна: {e}"

    def minimize_window(self, title_part: str, user_id: str) -> str:
        if not self.is_authorized(user_id):
            return "❌ У вас нет прав"
        try:
            win = self._get_window_by_title(title_part)
            if win:
                win.minimize()
                return f"✅ Окно `{win.title[:50]}` свёрнуто"
            else:
                return f"❌ Окно с заголовком, содержащим `{title_part}`, не найдено"
        except Exception as e:
            return f"❌ Ошибка сворачивания окна: {e}"

    # ---------- Открытие файлов/ярлыков с рабочего стола ----------
    def open_desktop_file(self, file_name: str, user_id: str) -> str:
        if not self.is_authorized(user_id):
            return "❌ У вас нет прав"
        try:
            desktop = Path(os.environ['USERPROFILE']) / 'Desktop'
            candidates = []
            for f in desktop.iterdir():
                if file_name.lower() in f.name.lower():
                    candidates.append(f)
            if not candidates:
                return f"❌ Файл или ярлык с именем, содержащим `{file_name}`, не найден на рабочем столе"
            target = candidates[0]
            os.startfile(target)
            return f"✅ Открыт `{target.name}`"
        except Exception as e:
            return f"❌ Ошибка открытия файла: {e}"

    # ---------- Открытие сайтов ----------
    def open_site(self, site_alias: str, user_id: str) -> str:
        if not self.is_authorized(user_id):
            return "❌ У вас нет прав"
        alias = site_alias.lower().strip()
        url = self.SITES.get(alias)
        if not url:
            return f"❌ Сайт `{site_alias}` не найден в базе. Доступные: {', '.join(self.SITES.keys())}"
        try:
            webbrowser.open(url)
            return f"✅ Открыт сайт: {url}"
        except Exception as e:
            return f"❌ Ошибка открытия сайта: {e}"

    # ---------- Процессы ----------
    def list_running_processes(self, user_id: str, filter_name: Optional[str] = None) -> str:
        if not self.is_authorized(user_id):
            return "❌ У вас нет прав"
        processes = []
        for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_info']):
            try:
                info = proc.info
                if filter_name and filter_name.lower() not in info['name'].lower():
                    continue
                mem_mb = info['memory_info'].rss / (1024 * 1024) if info['memory_info'] else 0
                processes.append(f"{info['pid']:>6} {info['name'][:25]:<25} CPU:{info['cpu_percent']:>5.1f}% MEM:{mem_mb:>7.1f}MB")
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        if not processes:
            return "ℹ️ Нет процессов, соответствующих фильтру"
        header = f"{'PID':>6} {'Имя':<25} {'CPU':>8} {'Память':>8}\n" + "-"*60
        return f"```\n{header}\n" + "\n".join(processes[:20]) + "\n```"

    def kill_process(self, pid: int, user_id: str) -> str:
        if not self.is_authorized(user_id):
            return "❌ У вас нет прав"
        try:
            proc = psutil.Process(pid)
            proc.terminate()
            return f"✅ Процесс {pid} ({proc.name()}) завершён"
        except psutil.NoSuchProcess:
            return f"❌ Процесс с PID {pid} не найден"
        except Exception as e:
            return f"❌ Ошибка: {e}"

    def take_screenshot(self, user_id: str) -> Optional[str]:
        if not self.is_authorized(user_id):
            return None
        try:
            screenshot = pyautogui.screenshot()
            path = Path("data/screenshot.png")
            path.parent.mkdir(exist_ok=True)
            screenshot.save(path)
            return str(path)
        except Exception as e:
            logger.error(f"Ошибка скриншота: {e}")
            return None

    def get_active_window_title(self, user_id: str) -> str:
        if not self.is_authorized(user_id):
            return "❌ Нет прав"
        try:
            import pygetwindow as gw
            active = gw.getActiveWindow()
            if active:
                return f"🪟 Активное окно: {active.title}"
            return "ℹ️ Не удалось определить активное окно"
        except Exception as e:
            return f"❌ Ошибка: {e}"