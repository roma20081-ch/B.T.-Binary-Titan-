import yaml
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict

@dataclass
class ModelConfig:
    name: str
    max_tokens: int
    temperature: float
    context_window: int
    priority: int
    min_ram_gb: float
    min_vram_gb: float

@dataclass
class AppConfig:
    discord_token: str = ""
    command_prefix: str = "!"
    ollama_host: str = "http://localhost:11434"
    ollama_timeout: int = 300
    models: Dict[str, ModelConfig] = field(default_factory=dict)
    max_queue_size: int = 100
    max_concurrent_tasks: int = 2
    cache_enabled: bool = True
    cache_ttl: int = 3600
    max_cache_size_mb: int = 500
    memory_enabled: bool = True
    max_memory_entries: int = 10000
    
    base_path: Path = Path(__file__).parent
    data_path: Path = base_path / 'data'
    plugins_path: Path = base_path / 'plugins'
    memory_path: Path = data_path / 'memory'
    cache_path: Path = data_path / 'cache'
    logs_path: Path = data_path / 'logs'
    
    def __post_init__(self):
        for path in [self.data_path, self.plugins_path, 
                    self.memory_path, self.cache_path, self.logs_path]:
            path.mkdir(parents=True, exist_ok=True)

def load_config(config_path: Path = None) -> AppConfig:
    if config_path is None:
       config_path = Path('C:/Users/You/Desktop/BT/config.yaml')
    
    with open(config_path, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    
    cfg = AppConfig()
    cfg.discord_token = data.get('discord', {}).get('token', '')
    cfg.command_prefix = data.get('discord', {}).get('command_prefix', '!')
    
    ollama = data.get('ollama', {})
    cfg.ollama_host = ollama.get('host', 'http://localhost:11434')
    cfg.ollama_timeout = ollama.get('timeout', 300)
    
    for model_type, model_data in data.get('models', {}).items():
        cfg.models[model_type] = ModelConfig(
            name=model_data['name'],
            max_tokens=model_data.get('max_tokens', 256),
            temperature=model_data.get('temperature', 0.7),
            context_window=model_data.get('context_window', 2048),
            priority=model_data.get('priority', 1),
            min_ram_gb=model_data.get('min_ram_gb', 4),
            min_vram_gb=model_data.get('min_vram_gb', 2)
        )
    
    queue = data.get('queue', {})
    cfg.max_queue_size = queue.get('max_size', 100)
    cfg.max_concurrent_tasks = queue.get('max_concurrent', 2)
    
    cache = data.get('cache', {})
    cfg.cache_enabled = cache.get('enabled', True)
    cfg.cache_ttl = cache.get('ttl', 3600)
    cfg.max_cache_size_mb = cache.get('max_size_mb', 500)
    
    memory = data.get('memory', {})
    cfg.memory_enabled = memory.get('enabled', True)
    cfg.max_memory_entries = memory.get('max_entries', 10000)
    
    return cfg

config = load_config()