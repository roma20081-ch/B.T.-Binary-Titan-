import json
import hashlib
import time
from pathlib import Path
from typing import Optional
from collections import OrderedDict
import logging

logger = logging.getLogger(__name__)

class MemoryManager:
    def __init__(self, memory_path: Path, cache_path: Path,
                 max_memory_entries=10000, cache_ttl=3600, max_cache_size_mb=500):
        self.memory_path = memory_path
        self.cache_path = cache_path
        self.max_memory_entries = max_memory_entries
        self.cache_ttl = cache_ttl
        self.max_cache_size_bytes = max_cache_size_mb * 1024 * 1024
        self.cache = OrderedDict()
        self.current_cache_size = 0

    def get_cache_key(self, text: str, model: str) -> str:
        content = f"{model}:{text}"
        return hashlib.md5(content.encode()).hexdigest()

    async def get_from_cache(self, text: str, model: str) -> Optional[str]:
        cache_key = self.get_cache_key(text, model)
        if cache_key in self.cache:
            entry = self.cache[cache_key]
            if time.time() - entry['timestamp'] < self.cache_ttl:
                self.cache.move_to_end(cache_key)
                logger.debug("🎯 Попадание в кэш")
                return entry['response']
            else:
                del self.cache[cache_key]
        cache_file = self.cache_path / f"{cache_key}.json"
        if cache_file.exists():
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    entry = json.load(f)
                if time.time() - entry['timestamp'] < self.cache_ttl:
                    self.cache[cache_key] = {'response': entry['response'], 'timestamp': entry['timestamp']}
                    return entry['response']
                else:
                    cache_file.unlink()
            except:
                pass
        return None

    async def add_to_cache(self, text: str, model: str, response: str):
        cache_key = self.get_cache_key(text, model)
        response_size = len(response)
        while self.current_cache_size + response_size > self.max_cache_size_bytes and self.cache:
            oldest_key = next(iter(self.cache))
            oldest_entry = self.cache[oldest_key]
            self.current_cache_size -= len(oldest_entry['response'])
            del self.cache[oldest_key]
        self.cache[cache_key] = {'response': response, 'timestamp': time.time()}
        self.current_cache_size += response_size
        cache_file = self.cache_path / f"{cache_key}.json"
        data = {'key': cache_key, 'model': model, 'response': response, 'timestamp': time.time()}
        try:
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Ошибка сохранения кэша: {e}")