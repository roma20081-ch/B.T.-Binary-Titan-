import discord
from discord.ext import commands
import logging

logger = logging.getLogger(__name__)

class DiscordBot:
    def __init__(self, assistant):
        self.assistant = assistant
        from config import config
        self.token = config.discord_token

        if not self.token or self.token == 'your_discord_bot_token_here':
            raise ValueError("❌ Токен Discord не настроен! Добавь его в config.yaml")

        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True

        self.bot = commands.Bot(
            command_prefix=config.command_prefix,
            intents=intents,
            help_command=None
        )
        self._setup_commands()

    def _setup_commands(self):
        # События
        @self.bot.event
        async def on_ready():
            logger.info(f'✅ Бот {self.bot.user} готов к работе')
            logger.info(f'📊 Подключен к {len(self.bot.guilds)} серверам')
            await self.bot.change_presence(
                activity=discord.Activity(
                    type=discord.ActivityType.listening,
                    name="!help для команд"
                )
            )

        @self.bot.event
        async def on_message(message):
            if message.author == self.bot.user or message.author.bot:
                return
            if message.content.startswith(self.bot.command_prefix):
                await self.bot.process_commands(message)
                return
            async with message.channel.typing():
                try:
                    response = await self.assistant.process_message(
                        message.content, str(message.author.id)
                    )
                    if len(response) > 2000:
                        chunks = [response[i:i+1900] for i in range(0, len(response), 1900)]
                        for chunk in chunks:
                            await message.reply(chunk)
                    else:
                        await message.reply(response)
                except Exception as e:
                    logger.error(f"Ошибка обработки: {e}")

        # Команды
        @self.bot.command(name='ask')
        async def ask_command(ctx, *, question: str):
            async with ctx.typing():
                response = await self.assistant.process_message(
                    question, str(ctx.author.id)
                )
                if len(response) > 2000:
                    chunks = [response[i:i+1900] for i in range(0, len(response), 1900)]
                    for chunk in chunks:
                        await ctx.reply(chunk)
                else:
                    await ctx.reply(response)

        @self.bot.command(name='code')
        async def code_command(ctx, *, task: str):
            async with ctx.typing():
                response = await self.assistant.ai_manager.query_model(
                    'coder',
                    f"Напиши код для следующей задачи:\n{task}\n\nОтветь кодом с пояснениями.",
                    system_prompt="Ты - эксперт программист. Пиши чистый, эффективный код с комментариями."
                )
                if '```' not in response:
                    lang = 'python'
                    if 'javascript' in task.lower() or 'js' in task.lower():
                        lang = 'javascript'
                    elif 'html' in task.lower():
                        lang = 'html'
                    elif 'css' in task.lower():
                        lang = 'css'
                    response = f"```{lang}\n{response}\n```"
                if len(response) > 2000:
                    chunks = [response[i:i+1900] for i in range(0, len(response), 1900)]
                    for chunk in chunks:
                        await ctx.reply(chunk)
                else:
                    await ctx.reply(response)

        @self.bot.command(name='stats')
        async def stats_command(ctx):
            stats = self.assistant.ai_manager.get_stats()
            resources = self.assistant.resource_monitor.get_resource_report()
            embed = discord.Embed(title="📊 Статистика нейросетей", color=discord.Color.blue())
            for model, data in stats.items():
                embed.add_field(
                    name=f"🤖 {model}",
                    value=f"Запросов: {data['calls']}\nТокенов: {data['tokens']}\nОшибок: {data['errors']}",
                    inline=True
                )
            embed.add_field(name="💻 Ресурсы", value=resources, inline=False)
            await ctx.reply(embed=embed)

        @self.bot.command(name='weather')
        async def weather_command(ctx, *, city: str = None):
            """Погода: !weather Москва или просто !weather (для Наро-Фоминска)"""
            try:
                result = await self.assistant.weather.get_weather(city)
            except Exception as e:
                result = f"❌ Ошибка погоды: {type(e).__name__}: {e}"
            await ctx.reply(result)

        @self.bot.command(name='run')
        async def run_command(ctx, *, command: str):
            user_id = str(ctx.author.id)
            response = await self.assistant.windows_controller.run_command(command, user_id)
            await ctx.reply(response)

        @self.bot.command(name='ps')
        async def ps_command(ctx, *, filter_name: str = None):
            user_id = str(ctx.author.id)
            response = self.assistant.windows_controller.list_running_processes(user_id, filter_name)
            await ctx.reply(response)

        @self.bot.command(name='kill')
        async def kill_command(ctx, pid: int):
            user_id = str(ctx.author.id)
            response = self.assistant.windows_controller.kill_process(pid, user_id)
            await ctx.reply(response)

        @self.bot.command(name='screen')
        async def screenshot_command(ctx):
            user_id = str(ctx.author.id)
            path = self.assistant.windows_controller.take_screenshot(user_id)
            if path:
                await ctx.reply(file=discord.File(path))
            else:
                await ctx.reply("❌ Не удалось сделать скриншот или недостаточно прав")

        @self.bot.command(name='window')
        async def window_command(ctx):
            user_id = str(ctx.author.id)
            response = self.assistant.windows_controller.get_active_window_title(user_id)
            await ctx.reply(response)

        @self.bot.command(name='remember')
        async def remember_command(ctx, alias: str, *, target_command: str):
            user_id = str(ctx.author.id)
            if not self.assistant.windows_controller.is_authorized(user_id):
                await ctx.reply("❌ У вас нет прав")
                return
            if self.assistant.windows_controller.custom_commands.add(alias, target_command):
                await ctx.reply(f"✅ Команда `{alias}` запомнена как `{target_command}`")
            else:
                await ctx.reply("❌ Ошибка при сохранении")

        @self.bot.command(name='forget')
        async def forget_command(ctx, alias: str):
            user_id = str(ctx.author.id)
            if not self.assistant.windows_controller.is_authorized(user_id):
                await ctx.reply("❌ У вас нет прав")
                return
            if self.assistant.windows_controller.custom_commands.remove(alias):
                await ctx.reply(f"🗑️ Команда `{alias}` удалена")
            else:
                await ctx.reply(f"❌ Команда `{alias}` не найдена")

        @self.bot.command(name='aliases')
        async def aliases_command(ctx):
            text = self.assistant.windows_controller.custom_commands.list_aliases()
            await ctx.reply(f"📋 Сохранённые команды:\n{text}")

        @self.bot.command(name='close')
        async def close_window_command(ctx, *, title_part: str):
            user_id = str(ctx.author.id)
            response = self.assistant.windows_controller.close_window(title_part, user_id)
            await ctx.reply(response)

        @self.bot.command(name='minimize')
        async def minimize_window_command(ctx, *, title_part: str):
            user_id = str(ctx.author.id)
            response = self.assistant.windows_controller.minimize_window(title_part, user_id)
            await ctx.reply(response)

        @self.bot.command(name='windows')
        async def list_windows_command(ctx):
            user_id = str(ctx.author.id)
            response = self.assistant.windows_controller.list_windows(user_id)
            await ctx.reply(response)

        @self.bot.command(name='open')
        async def open_file_command(ctx, *, file_name: str):
            user_id = str(ctx.author.id)
            response = self.assistant.windows_controller.open_desktop_file(file_name, user_id)
            await ctx.reply(response)

        @self.bot.command(name='site')
        async def open_site_command(ctx, *, site_alias: str):
            user_id = str(ctx.author.id)
            response = self.assistant.windows_controller.open_site(site_alias, user_id)
            await ctx.reply(response)

        @self.bot.command(name='volume')
        async def volume_command(ctx, level: int = None):
            user_id = str(ctx.author.id)
            if level is None:
                response = self.assistant.windows_controller.get_volume(user_id)
            else:
                response = self.assistant.windows_controller.set_volume(level, user_id)
            await ctx.reply(response)

        @self.bot.command(name='mute')
        async def mute_command(ctx):
            user_id = str(ctx.author.id)
            response = self.assistant.windows_controller.mute(user_id)
            await ctx.reply(response)

        @self.bot.command(name='news')
        async def news_command(ctx, source: str = 'rbc'):
            news_list = await self.assistant.news_fetcher.fetch_rss(source, 5)
            if not news_list:
                await ctx.reply("❌ Не удалось получить новости")
                return
            news_text = "\n".join([f"- {title}: {desc}" for title, desc in news_list])
            summary = await self.assistant.ai_manager.query_model(
                'powerful',
                f"Сделай краткую сводку следующих новостей (до 5 предложений):\n{news_text}",
                system_prompt="Ты – помощник, который делает сжатые и информативные сводки новостей на русском языке."
            )
            await ctx.reply(f"📰 **Сводка новостей ({source}):**\n{summary}")

        @self.bot.command(name='scenario')
        async def scenario_command(ctx, action: str, *, args: str = None):
            user_id = str(ctx.author.id)
            if not self.assistant.windows_controller.is_authorized(user_id):
                await ctx.reply("❌ У вас нет прав")
                return
            if action == 'list':
                text = self.assistant.scenario_manager.list_scenarios()
                await ctx.reply(f"🎭 **Сценарии:**\n{text}")
            elif action == 'add' and args:
                parts = args.split(':', 1)
                if len(parts) != 2:
                    await ctx.reply("❌ Формат: !scenario add название: действие1; действие2")
                    return
                trigger = parts[0].strip()
                actions_str = parts[1].strip()
                actions = [a.strip() for a in actions_str.split(';') if a.strip()]
                if not actions:
                    await ctx.reply("❌ Укажите хотя бы одно действие")
                    return
                self.assistant.scenario_manager.add_scenario(trigger, actions)
                await ctx.reply(f"✅ Сценарий `{trigger}` добавлен")
            elif action == 'remove' and args:
                if self.assistant.scenario_manager.remove_scenario(args.strip()):
                    await ctx.reply(f"✅ Сценарий `{args}` удалён")
                else:
                    await ctx.reply(f"❌ Сценарий `{args}` не найден")
            else:
                await ctx.reply("Используйте: !scenario list / add / remove")

        @self.bot.command(name='ai')
        async def set_ai_mode(ctx, mode: str = None):
            if mode is None:
                current = self.assistant.force_model or "авто"
                await ctx.reply(f"🧠 Текущий режим: {current}")
                return
            mode = mode.lower()
            if mode in ('fast', 'medium', 'hard', 'powerful', 'coder'):
                self.assistant.force_model = mode if mode != 'hard' else 'powerful'
                await ctx.reply(f"✅ Режим принудительно установлен: {mode}")
            elif mode == 'auto':
                self.assistant.force_model = None
                await ctx.reply("🔄 Режим возвращён в авто (нейросеть выбирает сама)")
            else:
                await ctx.reply("❌ Неизвестный режим. Доступные: fast, medium, hard, coder, auto")

        @self.bot.command(name='search')
        async def search_command(ctx, *, query: str):
            async with ctx.typing():
                page_text = await self.assistant.web_searcher.search_and_extract(query)
                if not page_text:
                    await ctx.reply("❌ Не удалось найти информацию")
                    return
                summary = await self.assistant.ai_manager.query_model(
                    'powerful',
                    f"Прочитай текст и дай краткий, информативный ответ на русском языке (2-4 предложения), "
                    f"основанный на следующей информации:\n\n{page_text}\n\nЗапрос: {query}",
                    system_prompt="Ты — полезный ассистент, который кратко отвечает на вопросы, используя предоставленный текст."
                )
                await ctx.reply(f"🔍 **Результат поиска:**\n{summary}")

        @self.bot.command(name='автозагрузка')
        async def toggle_autostart(ctx, action: str = None):
            """Управление автозагрузкой бота (планировщик): !автозагрузка on/off/status"""
            import subprocess
            task_name = "BTAssistant"
            if action == 'on':
                subprocess.run(['schtasks', '/Change', '/TN', task_name, '/ENABLE'], capture_output=True)
                await ctx.reply("✅ Задача автозагрузки бота включена.")
            elif action == 'off':
                subprocess.run(['schtasks', '/Change', '/TN', task_name, '/DISABLE'], capture_output=True)
                await ctx.reply("❌ Задача автозагрузки бота отключена.")
            else:
                result = subprocess.run(['schtasks', '/Query', '/TN', task_name], capture_output=True, text=True)
                if "Disabled" in result.stdout:
                    status = "отключена"
                elif "Ready" in result.stdout:
                    status = "включена"
                else:
                    status = "не найдена"
                await ctx.reply(f"Статус автозагрузки бота: {status}\nИспользуйте !автозагрузка on/off")

        @self.bot.command(name='help')
        async def help_command(ctx):
            embed = discord.Embed(
                title="🤖 BT Assistant - Справка",
                description="Я - AI ассистент с функциями управления Windows",
                color=discord.Color.green()
            )
            embed.add_field(
                name="📝 Основные команды",
                value="**!ask <вопрос>** - Задать вопрос нейросети\n"
                      "**!code <задача>** - Генерация кода (модель Coder)\n"
                      "**!stats** - Статистика использования\n"
                      "**!help** - Эта справка",
                inline=False
            )
            embed.add_field(
                name="🖥️ Управление Windows",
                value="**!run <программа>** - Запустить разрешённое приложение\n"
                      "**!ps [фильтр]** - Список процессов\n"
                      "**!kill <PID>** - Завершить процесс\n"
                      "**!screen** - Скриншот экрана\n"
                      "**!window** - Заголовок активного окна",
                inline=False
            )
            embed.add_field(
                name="🪟 Управление окнами",
                value="**!close <часть названия>** - Закрыть окно\n"
                      "**!minimize <часть названия>** - Свернуть окно\n"
                      "**!windows** - Показать список открытых окон",
                inline=False
            )
            embed.add_field(
                name="📁 Файлы и сайты",
                value="**!open <имя файла>** - Открыть файл/ярлык с рабочего стола\n"
                      "**!site <название>** - Открыть сайт (вк, ютуб, дипсик)",
                inline=False
            )
            embed.add_field(
                name="🌤️ Погода",
                value="**!weather [город]** - Показать погоду\n"
                      "**погода** - без префикса (для Наро-Фоминска)",
                inline=False
            )
            embed.add_field(
                name="🌐 Интернет-поиск",
                value="**!search <запрос>** - Найти в интернете и кратко ответить\n"
                      "**найди <запрос>** - без префикса",
                inline=False
            )
            embed.add_field(
                name="🔊 Звук",
                value="**!volume [0-100]** - Показать/установить громкость\n"
                      "**!mute** - Вкл/выкл беззвучный режим\n"
                      "**громкость 50** - без префикса",
                inline=False
            )
            embed.add_field(
                name="📰 Новости",
                value="**!news [rbc/lenta/ria]** - Сводка новостей\n"
                      "**новости** - без префикса",
                inline=False
            )
            embed.add_field(
                name="🎭 Сценарии",
                value="**!scenario list** - Показать сценарии\n"
                      "**!scenario add фраза: open:хром; volume:100**\n"
                      "**!scenario remove фраза**\n"
                      "Срабатывают при точном совпадении фразы",
                inline=False
            )
            embed.add_field(
                name="🧠 Выбор модели",
                value="**!ai fast/medium/hard/coder/auto** - Переключить нейросеть",
                inline=False
            )
            embed.add_field(
                name="💬 Упоминания",
                value="Просто упомяни меня (@бот) и задай вопрос, "
                      "или используй префикс `!`",
                inline=False
            )
            await ctx.reply(embed=embed)

    async def start(self):
        try:
            await self.bot.start(self.token)
        except discord.LoginFailure:
            logger.error("❌ Ошибка: Неверный токен Discord!")
        except Exception as e:
            logger.error(f"❌ Ошибка запуска: {e}")