import psutil
import asyncio
from dataclasses import dataclass
from typing import Optional
import logging

logger = logging.getLogger(__name__)

@dataclass
class SystemResources:
    cpu_percent: float
    ram_used_gb: float
    ram_total_gb: float
    vram_used_gb: Optional[float] = None
    vram_total_gb: Optional[float] = None
    gpu_available: bool = False
    
    @property
    def ram_free_gb(self) -> float:
        return self.ram_total_gb - self.ram_used_gb
    
    @property
    def vram_free_gb(self) -> Optional[float]:
        if self.vram_total_gb and self.vram_used_gb:
            return self.vram_total_gb - self.vram_used_gb
        return None

class ResourceMonitor:
    def __init__(self, check_interval: float = 5.0):
        self.check_interval = check_interval
        self.current_resources = None
        self._monitoring = False
        self._task = None
        
    async def start_monitoring(self):
        self._monitoring = True
        self._task = asyncio.create_task(self._monitor_loop())
        logger.info("📊 Мониторинг ресурсов запущен")
        
    async def stop_monitoring(self):
        self._monitoring = False
        if self._task:
            self._task.cancel()
            
    async def _monitor_loop(self):
        while self._monitoring:
            try:
                self.current_resources = await self.get_system_resources()
                await asyncio.sleep(self.check_interval)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Ошибка мониторинга: {e}")
                
    async def get_system_resources(self):
        cpu_percent = psutil.cpu_percent(interval=1)
        ram = psutil.virtual_memory()
        ram_used_gb = ram.used / (1024**3)
        ram_total_gb = ram.total / (1024**3)
        
        vram_used_gb = None
        vram_total_gb = None
        gpu_available = False
        
        try:
            import GPUtil
            gpus = GPUtil.getGPUs()
            if gpus:
                gpu = gpus[0]
                vram_used_gb = gpu.memoryUsed / 1024
                vram_total_gb = gpu.memoryTotal / 1024
                gpu_available = True
        except Exception as e:
            logger.debug(f"GPU недоступен: {e}")
            
        return SystemResources(
            cpu_percent=cpu_percent,
            ram_used_gb=ram_used_gb,
            ram_total_gb=ram_total_gb,
            vram_used_gb=vram_used_gb,
            vram_total_gb=vram_total_gb,
            gpu_available=gpu_available
        )
    
    def can_run_model(self, min_ram_gb, min_vram_gb=0):
        if not self.current_resources:
            return True
        resources = self.current_resources
        if resources.ram_free_gb < min_ram_gb:
            logger.warning(f"Недостаточно RAM: {resources.ram_free_gb:.1f}GB < {min_ram_gb}GB")
            return False
        if min_vram_gb > 0 and resources.gpu_available:
            if resources.vram_free_gb < min_vram_gb:
                logger.warning(f"Недостаточно VRAM: {resources.vram_free_gb:.1f}GB < {min_vram_gb}GB")
                return False
        return True
    
    def get_resource_report(self):
        if not self.current_resources:
            return "📊 Нет данных о ресурсах"
        r = self.current_resources
        report = f"🖥️ CPU: {r.cpu_percent}%\n💾 RAM: {r.ram_used_gb:.1f}/{r.ram_total_gb:.1f} GB\n"
        if r.gpu_available:
            report += f"🎮 VRAM: {r.vram_used_gb:.1f}/{r.vram_total_gb:.1f} GB"
        else:
            report += "🎮 GPU: Недоступен"
        return report