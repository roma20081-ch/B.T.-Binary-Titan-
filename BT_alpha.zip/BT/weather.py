import aiohttp
import json

class Weather:
    def __init__(self, default_city: str = "Наро-Фоминск"):
        self.default_city = default_city

    async def get_weather(self, city: str = None) -> str:
        if city is None:
            city = self.default_city
        try:
            url = f"http://wttr.in/{city}?format=j1&lang=ru"
            timeout = aiohttp.ClientTimeout(total=30)
            connector = aiohttp.TCPConnector(ssl=False)
            async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
                async with session.get(url) as resp:
                    if resp.status != 200:
                        return f"❌ Ошибка сервера погоды ({resp.status})"
                    text = await resp.text()
                    data = json.loads(text)
                    current = data['current_condition'][0]
                    weather_desc = current['lang_ru'][0]['value']
                    temp_c = current['temp_C']
                    feels_like = current['FeelsLikeC']
                    humidity = current['humidity']
                    wind_speed = current['windspeedKmph']
                    wind_dir = current['winddir16Point']
                    
                    return (
                        f"🌍 **{city}**\n"
                        f"🌡️ Температура: {temp_c}°C (ощущается как {feels_like}°C)\n"
                        f"☁️ {weather_desc}\n"
                        f"💧 Влажность: {humidity}%\n"
                        f"💨 Ветер: {wind_speed} км/ч, {wind_dir}"
                    )
        except Exception as e:
            return f"❌ Ошибка: {type(e).__name__}: {e}"